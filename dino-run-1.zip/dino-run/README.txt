DINO RUN  -  run guide
=======================
public/   -> the game (index.html + PWA files). Works fully offline once opened (service worker caches it).
server/   -> optional Node.js server (no npm packages). Gives: global leaderboard, profile photos, share-gallery links.

Start (needs Node 18+):
  cd server
  node server.js            (PORT=8080 by default; set PORT=3000 to change; DATA_DIR=/path to keep data elsewhere)
Open http://localhost:8080

Put it on the internet: run the same command on any Node host (Render, Railway, Fly, a VPS) behind HTTPS.
The game finds the API by itself (same domain), so no config is needed. Without the server the game still
works: score stays on the phone, leaderboard shows OFFLINE with only the local player.

Leaderboard = total of ALL runs a player ever plays (it keeps adding). Names look like @guest6488 until the player edits them.
Data lives in server/data/ (users.json + shares/). Back it up by copying that folder.

Not included yet (do before a big public launch): anti-cheat for scores, abuse/DDoS protection (use Cloudflare),
cleanup of old share galleries, moderation of profile photos.
