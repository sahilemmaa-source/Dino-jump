'use strict';
// Dino Run server: static hosting + leaderboard + share-gallery. No dependencies. Run: node server.js
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=+process.env.PORT||8080,ROOT=path.join(__dirname,'..','public'),DATA=process.env.DATA_DIR||path.join(__dirname,'data');
fs.mkdirSync(path.join(DATA,'shares'),{recursive:true});
const UF=path.join(DATA,'users.json');let U={};try{U=JSON.parse(fs.readFileSync(UF,'utf8'))}catch(e){}
let dirty=false;const flush=()=>{if(dirty){dirty=false;fs.writeFile(UF+'.tmp',JSON.stringify(U),e=>{if(!e)fs.rename(UF+'.tmp',UF,()=>{})})}};
setInterval(flush,2000).unref();process.on('SIGINT',()=>{flush();setTimeout(()=>process.exit(0),200)});process.on('SIGTERM',()=>{flush();setTimeout(()=>process.exit(0),200)});
const MIME={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.png':'image/png','.svg':'image/svg+xml','.ico':'image/x-icon'};
const HDR={'x-content-type-options':'nosniff','referrer-policy':'same-origin'};
const send=(res,code,body,type,extra)=>{res.writeHead(code,Object.assign({'content-type':type||'application/json','cache-control':'no-store'},HDR,extra||{}));res.end(typeof body==='string'||Buffer.isBuffer(body)?body:JSON.stringify(body))};
const readBody=(req,max)=>new Promise((ok,no)=>{let n=0;const b=[];req.on('data',c=>{n+=c.length;if(n>max){no(413);req.destroy()}else b.push(c)});req.on('end',()=>ok(Buffer.concat(b).toString('utf8')));req.on('error',()=>no(400))});
const rl=new Map();const limited=(k,ms)=>{const n=Date.now(),p=rl.get(k)||0;if(n-p<ms)return true;rl.set(k,n);if(rl.size>5000)for(const[x,v]of rl)if(n-v>60000)rl.delete(x);return false};
const okId=s=>typeof s==='string'&&/^[0-9a-f]{16}$/.test(s),okName=s=>typeof s==='string'&&/^@[a-z0-9_.]{3,16}$/.test(s);
const esc=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function gallery(id,n,origin){const im=[...Array(n).keys()].map(i=>`<img src="/api/img/${id}/${i}" alt="Dino Run photo ${i+1}" loading="${i?'lazy':'eager'}">`).join('');
return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Dino Run photos</title><meta property="og:title" content="Dino Run"><meta property="og:image" content="${origin}/api/img/${id}/0"><style>html,body{margin:0;height:100%;background:#fff;font:700 16px system-ui,sans-serif}body{display:flex;flex-direction:column}header{padding:12px 16px;display:flex;gap:12px;align-items:center;justify-content:space-between;border-bottom:3px solid #141413}header span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:13px;color:#555}a.p{background:#141413;color:#fff;padding:10px 18px;border-radius:999px;text-decoration:none}main{flex:1;display:flex;gap:14px;overflow-x:auto;scroll-snap-type:x mandatory;padding:16px}main img{flex:none;height:100%;max-width:86vw;object-fit:contain;scroll-snap-align:center;border:3px solid #141413;border-radius:28px;background:#fff}</style></head><body><header><span>${esc(origin)}/s/${id}</span><a class="p" href="/">Play Dino Run</a></header><main>${im}</main></body></html>`}
const server=http.createServer(async(req,res)=>{try{const u=new URL(req.url,'http://x'),p=u.pathname,ip=req.socket.remoteAddress||'';
if(p==='/api/top'&&req.method==='GET'){const n=Math.max(1,Math.min(100,+u.searchParams.get('n')||100));const a=Object.entries(U).map(([id,v])=>({id,name:v.name,total:v.total,av:v.photo?1:0,v:v.pv||0})).sort((x,y)=>y.total-x.total||(x.id<y.id?-1:1));return send(res,200,{list:a.slice(0,n),t:Date.now()})}
if(p==='/api/score'&&req.method==='POST'){let j;try{j=JSON.parse(await readBody(req,200e3))}catch(e){return send(res,400,{err:'bad'})}
if(!okId(j.id)||!okName(j.name))return send(res,400,{err:'bad'});const add=Math.max(0,Math.min(20000,Math.floor(+j.add||0)));
if(add&&limited('s'+j.id,1500))return send(res,429,{err:'slow'});if(limited('ip'+ip,150))return send(res,429,{err:'slow'});
for(const k in U)if(k!==j.id&&U[k].name===j.name)return send(res,409,{err:'taken'});
const v=U[j.id]||(U[j.id]={name:j.name,total:0,pv:0});v.name=j.name;v.total+=add;
if(typeof j.photo==='string'&&/^data:image\/jpeg;base64,[A-Za-z0-9+/=]{100,60000}$/.test(j.photo)){v.photo=j.photo.slice(23);v.pv=(v.pv||0)+1}
dirty=true;return send(res,200,{total:v.total})}
let m=p.match(/^\/api\/av\/([0-9a-f]{16})$/);if(m&&req.method==='GET'){const v=U[m[1]];if(!v||!v.photo)return send(res,404,{err:'none'});return send(res,200,Buffer.from(v.photo,'base64'),'image/jpeg',{'cache-control':'public,max-age=31536000,immutable'})}
if(p==='/api/share'&&req.method==='POST'){if(limited('sh'+ip,3000))return send(res,429,{err:'slow'});let j;try{j=JSON.parse(await readBody(req,14e6))}catch(e){return send(res,400,{err:'bad'})}
if(!Array.isArray(j.imgs)||!j.imgs.length||j.imgs.length>30)return send(res,400,{err:'bad'});const id=crypto.randomBytes(6).toString('hex'),dir=path.join(DATA,'shares',id);fs.mkdirSync(dir);let n=0;
for(const d of j.imgs){const mm=typeof d==='string'&&d.match(/^data:image\/png;base64,([A-Za-z0-9+/=]+)$/);if(!mm||mm[1].length>1.6e6)continue;fs.writeFileSync(path.join(dir,n+'.png'),Buffer.from(mm[1],'base64'));n++}
if(!n){fs.rmdirSync(dir);return send(res,400,{err:'bad'})}return send(res,200,{id,n})}
m=p.match(/^\/api\/img\/([0-9a-f]{12})\/(\d{1,2})$/);if(m&&req.method==='GET'){const f=path.join(DATA,'shares',m[1],m[2]+'.png');if(!fs.existsSync(f))return send(res,404,{err:'none'});return send(res,200,fs.readFileSync(f),'image/png',{'cache-control':'public,max-age=31536000,immutable'})}
m=p.match(/^\/s\/([0-9a-f]{12})$/);if(m&&req.method==='GET'){const dir=path.join(DATA,'shares',m[1]);if(!fs.existsSync(dir))return send(res,404,'Not found','text/plain');const n=fs.readdirSync(dir).length,proto=req.headers['x-forwarded-proto']||'http';return send(res,200,gallery(m[1],n,proto+'://'+req.headers.host),'text/html;charset=utf-8')}
if(req.method!=='GET'&&req.method!=='HEAD')return send(res,405,{err:'method'});
let f=path.normalize(path.join(ROOT,p==='/'?'index.html':decodeURIComponent(p)));if(!f.startsWith(ROOT)||!fs.existsSync(f)||fs.statSync(f).isDirectory())return send(res,404,'Not found','text/plain');
send(res,200,fs.readFileSync(f),MIME[path.extname(f)]||'application/octet-stream',{'cache-control':p==='/sw.js'||p==='/'||p.endsWith('.html')?'no-cache':'public,max-age=86400'})}catch(e){try{send(res,500,{err:'server'})}catch(_){}}});
server.listen(PORT,()=>console.log('Dino Run on http://localhost:'+PORT));
